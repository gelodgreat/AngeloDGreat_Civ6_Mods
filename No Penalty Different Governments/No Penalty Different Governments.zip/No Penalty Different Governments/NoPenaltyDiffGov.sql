UPDATE Governments SET OtherGovernmentIntolerance = 0 WHERE  GovernmentType='GOVERNMENT_AUTOCRACY';
UPDATE Governments SET OtherGovernmentIntolerance = 0 WHERE  GovernmentType='GOVERNMENT_OLIGARCHY';
UPDATE Governments SET OtherGovernmentIntolerance = 0 WHERE  GovernmentType='GOVERNMENT_CLASSICAL_REPUBLIC';
UPDATE Governments SET OtherGovernmentIntolerance = 0 WHERE  GovernmentType='GOVERNMENT_MONARCHY';
UPDATE Governments SET OtherGovernmentIntolerance = 0 WHERE  GovernmentType='GOVERNMENT_THEOCRACY';
UPDATE Governments SET OtherGovernmentIntolerance = 0 WHERE  GovernmentType='GOVERNMENT_MERCHANT_REPUBLIC';
UPDATE Governments SET OtherGovernmentIntolerance = 0 WHERE  GovernmentType='GOVERNMENT_FASCISM';
UPDATE Governments SET OtherGovernmentIntolerance = 0 WHERE  GovernmentType='GOVERNMENT_COMMUNISM';
UPDATE Governments SET OtherGovernmentIntolerance = 0 WHERE  GovernmentType='GOVERNMENT_DEMOCRACY';
--JFD Governments you can remove this lines below if you're not playing with JFD's Rule of Faith
UPDATE Governments SET OtherGovernmentIntolerance = 0 WHERE  GovernmentType='GOVERNMENT_JFD_ABSOLUTE_MONARCHY';
UPDATE Governments SET OtherGovernmentIntolerance = 0 WHERE  GovernmentType='GOVERNMENT_JFD_CONSTITUTIONAL_MONARCHY';
UPDATE Governments SET OtherGovernmentIntolerance = 0 WHERE  GovernmentType='GOVERNMENT_JFD_NOBLE_REPUBLIC';