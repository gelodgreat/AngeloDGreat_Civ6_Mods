INSERT INTO BaseGameText (Tag,Text) VALUES ('LOC_TRAIT_CIVILIZATION_EXTRA_MELEEE_UNIT_NAME','Extra Melee Units');
INSERT INTO BaseGameText (Tag,Text) VALUES ('LOC_TRAIT_CIVILIZATION_EXTRA_MELEEE_UNIT_DESCRIPTION','Provides another set of melee units.</');
INSERT INTO BaseGameText (Tag,Text) VALUES ('LOC_TRAIT_CIVILIZATION_EXTRA_HEAVY_CAVALRY_NAME','Extra Heavy Calvalry Units');
INSERT INTO BaseGameText (Tag,Text) VALUES ('LOC_TRAIT_CIVILIZATION_EXTRA_HEAVY_CAVALRY_DESCRIPTION','Provides another set of heavy calvalry units.</');
INSERT INTO BaseGameText (Tag,Text) VALUES ('LOC_TRAIT_CIVILIZATION_FASTER_BORDER_GROWTH_NAME','70 Percent Border Growth');
INSERT INTO BaseGameText (Tag,Text) VALUES ('LOC_TRAIT_CIVILIZATION_FASTER_BORDER_GROWTH_DESCRIPTION','Faster Border growth with a value of 70 Percent.');
INSERT INTO BaseGameText (Tag,Text) VALUES ('LOC_TRAIT_CIVILIZATION_MANY_BUILDER_CHARGE_NAME','Many Builder Charge');
INSERT INTO BaseGameText (Tag,Text) VALUES ('LOC_TRAIT_CIVILIZATION_MANY_BUILDER_CHARGE_DESCRIPTION','Gives builder a super many charge.');
INSERT INTO BaseGameText (Tag,Text) VALUES ('LOC_TRAIT_CIVILIZATION_ONEFORALL_MILITARY_MELEE_PROD_NAME','Gives production boost in creating melee units.');
INSERT INTO BaseGameText (Tag,Text) VALUES ('LOC_TRAIT_CIVILIZATION_ONEFORALL_MILITARY_MELEE_PROD_DESCRIPTION','Gives Huge production boost in creating melee units for a certain civilization.');
-- Suzerain BONUS Text
INSERT INTO BaseGameText (Tag,Text) VALUES ('LOC_TRAIT_ALL_SUZERAIN_BONUSES_NAME','King of Kings');